<?php
function elementor_theme_setup() {
    // Add theme support for dynamic title tag and post thumbnails
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');

    // Register navigation menu
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'elementor-theme'),
    ));

    // Enable Elementor compatibility
    add_theme_support('elementor-experimental-theme-builder');
}
add_action('after_setup_theme', 'elementor_theme_setup');

// Enqueue styles and scripts
function elementor_theme_scripts() {
    wp_enqueue_style('theme-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'elementor_theme_scripts');

