<?php
if ( function_exists('elementor_theme_do_location') && elementor_theme_do_location('footer') ) {
    elementor_theme_do_location('footer');
} else { ?>
    <footer>
        <p>&copy; <?php echo date('Y'); ?> All rights reserved.</p>
    </footer>
<?php } ?>
<?php wp_footer(); ?>
</body>
</html>
