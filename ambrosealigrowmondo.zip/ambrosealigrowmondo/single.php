<?php get_header(); ?>
<main>
    <h1><?php the_title(); ?></h1>
    <p><?php the_date(); ?> | By <?php the_author(); ?></p>
    <?php the_content(); ?>
</main>
<?php get_footer(); ?>
